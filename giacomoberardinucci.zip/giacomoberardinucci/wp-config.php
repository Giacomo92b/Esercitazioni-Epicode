<?php

// BEGIN iThemes Security - Do not modify or remove this line
// iThemes Security Config Details: 2
define( 'DISALLOW_FILE_EDIT', true ); // Disable File Editor - Security > Settings > WordPress Tweaks > File Editor
// END iThemes Security - Do not modify or remove this line

define( 'ITSEC_ENCRYPTION_KEY', 'VWwvYHVLbTRzY3VWTixLOUtXI2dwPCthP0t2MyleMlVJOSFBeiF3eXQwJT8jfiQjJjdxfip6TD5FMFQrY0l+QQ==' );

//Begin Really Simple SSL session cookie settings
@ini_set('session.cookie_httponly', true);
@ini_set('session.cookie_secure', true);
@ini_set('session.use_only_cookies', true);
//END Really Simple SSL cookie settings
/**
 * Il file base di configurazione di WordPress.
 *
 * Questo file viene utilizzato, durante l’installazione, dallo script
 * di creazione di wp-config.php. Non è necessario utilizzarlo solo via web
 * puoi copiare questo file in «wp-config.php» e riempire i valori corretti.
 *
 * Questo file definisce le seguenti configurazioni:
 *
 * * Impostazioni del database
 * * Chiavi segrete
 * * Prefisso della tabella
 * * ABSPATH
 *
 * * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Impostazioni database - È possibile ottenere queste informazioni dal proprio fornitore di hosting ** //
/** Il nome del database di WordPress */
define( 'DB_NAME', 'giacomoberardinucci' );

/** Nome utente del database */
define( 'DB_USER', 'root' );

/** Password del database */
define( 'DB_PASSWORD', '' );

/** Hostname del database */
define( 'DB_HOST', 'localhost' );

/** Charset del Database da utilizzare nella creazione delle tabelle. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Il tipo di collazione del database. Da non modificare se non si ha idea di cosa sia. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chiavi univoche di autenticazione e di sicurezza.
 *
 * Modificarle con frasi univoche differenti!
 * È possibile generare tali chiavi utilizzando {@link https://api.wordpress.org/secret-key/1.1/salt/ servizio di chiavi-segrete di WordPress.org}
 *
 * È possibile cambiare queste chiavi in qualsiasi momento, per invalidare tutti i cookie esistenti.
 * Ciò forzerà tutti gli utenti a effettuare nuovamente l'accesso.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '<n<?x7=HF!?z.2lz_9W4/#hsw6.Pi!r v0Vq.|TG8Wd2DQa@!bZy^2=$h]*:tk,B' );
define( 'SECURE_AUTH_KEY',  'K,QlePX?{-/-c,61}i3|1LYCG)$L0#*ZDMgf|PVdVq^e<tj W `Peej+J*cZ$KtP' );
define( 'LOGGED_IN_KEY',    'phsrk{ai/.6Qk:H4<sr?V<;TLu2&d5ICVKarN=+~ew7br=+PX;(nDmr=Z07%wHww' );
define( 'NONCE_KEY',        '$7!?R1B]lQ>:xEg&B.cF|.!{>F88_xxDgPRX#-kJm_//&V(y4Tf7t^_1(8oa6:Gy' );
define( 'AUTH_SALT',        'cd>mGrI{8(gCbo9MT4U=Q8q7`R-S|HI4b.|EmZ@T4pv24#_9)(8-~t>#:`-=Am0^' );
define( 'SECURE_AUTH_SALT', ',&*m`*G[}2KI|-| >ZA$r?%b1s%IP_Z1GoDajKB3Go]#Q1),8<6k~uN<TzsP-mkX' );
define( 'LOGGED_IN_SALT',   ' Ti;p[.Ge,r^Lgb8{.u7Kz*Ow2~A.D2rLcFRVBa+$qD@t>->h.fdt*V!wc7&ez[m' );
define( 'NONCE_SALT',       'A336=CxPc2WPFQ=s35wAoEW+?fUg_<@,A|gV9u=u4##|Qh=8+cH tL xpQy/(@V|' );

/**#@-*/

/**
 * Prefisso tabella del database WordPress.
 *
 * È possibile avere installazioni multiple su di un unico database
 * fornendo a ciascuna installazione un prefisso univoco. Solo numeri, lettere e trattini bassi!
 */
$table_prefix = 'gb_';

/**
 * Per gli sviluppatori: modalità di debug di WordPress.
 *
 * Modificare questa voce a TRUE per abilitare la visualizzazione degli avvisi durante lo sviluppo
 * È fortemente raccomandato agli svilupaptori di temi e plugin di utilizare
 * WP_DEBUG all’interno dei loro ambienti di sviluppo.
 *
 * Per informazioni sulle altre costanti che possono essere utilizzate per il debug,
 * leggi la documentazione
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Aggiungere qualsiasi valore personalizzato tra questa riga e la riga "Finito, interrompere le modifiche". */



/* Finito, interrompere le modifiche! Buona pubblicazione. */

/** Path assoluto alla directory di WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Imposta le variabili di WordPress ed include i file. */
require_once ABSPATH . 'wp-settings.php';
